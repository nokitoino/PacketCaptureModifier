#pragma once
#include "structures.h"

void captureToTerminal(pcap_t* handle, int captureAmount);
void captureToFile();
