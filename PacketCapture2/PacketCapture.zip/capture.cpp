#include "device.h"
#include "checksum.h"
void captureToTerminal(pcap_t* handle, int captureAmount) {
	pcap_loop(handle, captureAmount, got_packet, NULL);
}
void captureToFile() {

}

void
got_packet(u_char* args, const struct pcap_pkthdr* header, const u_char* packet)
{
	static int count = 1;                  /* packet counter */
	/* declare pointers to packet headers */
	const struct sniff_ethernet* ethernet;  /* The ethernet header [1] */
	struct sniff_ip* ip;              /* The IP header */
	const struct sniff_tcp* tcp;            /* The TCP header */
	const u_char* payload;                    /* Packet payload */
	struct pseudoheader p;
	int size_ip;
	int size_tcp;
	int size_payload;
	std::cout << "Package captured" << count << std::endl;
	count++;


	return;
}