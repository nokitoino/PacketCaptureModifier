#include"device.h"
#include"capture.h"

pcap_if_t* dev;
pcap_t* handle;
struct bpf_program fp;
bpf_u_int32 mask;
bpf_u_int32 net;
char filter_exp[] = "port 2083";
int captureAmount = 200;
int main() {

	getDevice(dev); /* pcpa_if_t* dev */
	openDevice(dev, handle);/* pcap_t* handle */
	applyFilter(dev, handle, fp,  net, mask, filter_exp); /* compiles and applies */
	captureToTerminal(handle, captureAmount);
	std::cout << "Finish, type and press enter." << std::endl;
	std::cin.ignore();

	clearDevice(handle, fp);
	return 0;
}