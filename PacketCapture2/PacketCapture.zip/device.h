#pragma once
#include "structures.h"

void getDevice(pcap_if_t* &dev); /* pcpa_if_t* dev */
void openDevice(pcap_if_t* &dev, pcap_t* &handle);/* pcap_t* handle */
void applyFilter(pcap_if_t* &dev, pcap_t* &handle, struct bpf_program& fp, bpf_u_int32& net, bpf_u_int32& mask, const char* filter_exp); /* compiles and applies */
void clearDevice(pcap_t* &handle, struct bpf_program& fp); /* free filter and close handle*/