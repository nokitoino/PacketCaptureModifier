#include "device.h"


char errbuf[PCAP_ERRBUF_SIZE];
void getDevice(pcap_if_t* &dev) {

	pcap_if_t* alldevs;
	if (pcap_findalldevs(&alldevs, errbuf) == -1) {
		std::cerr << "Could not find any device" << errbuf << std::endl;
		exit;
	}
	dev = alldevs->next; // remove or add more ->next to find your device!
}
void openDevice(pcap_if_t* &dev, pcap_t* &handle) {
	handle = pcap_open_live(dev->name, BUFSIZ, 0, 100, errbuf);
	if (handle == NULL) {
		std::cerr << "Could not open the device " << errbuf << std::endl;
	}
	if (pcap_datalink(handle) != DLT_EN10MB) {
		std::cout << "Device does not support 802.3 Ethernet 2 " << errbuf << std::endl;
	}
}
void applyFilter(pcap_if_t* &dev, pcap_t* &handle, struct bpf_program& fp, bpf_u_int32& net, bpf_u_int32& mask, const char * filter_exp) {
	if (pcap_lookupnet(dev->name, &net, &mask, errbuf) == -1) {
		std::cerr << "Netmask not found " << errbuf << std::endl;
	}
	if (pcap_compile(handle, &fp, filter_exp, 0, net) == -1) {
		std::cerr << "Filter expression is wrong : " << filter_exp << std::endl;
	}
	if (pcap_setfilter(handle, &fp) == -1) {
		std::cerr << "Filter could not be applied  " << filter_exp << std::endl;
	}
}
void clearDevice(pcap_t* &handle, struct bpf_program& fp) {
	pcap_freecode(&fp);
	pcap_close(handle);
}